package com.stackroute.resttemplate.service;

import com.stackroute.resttemplate.model.Weather;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
public class WeatherService {

    //add your api key here
    private static final String API_KEY = "c46dbffee7c2f17c23e93c6692746d0f";

    //add the base api url here
    private static final String API_URL = "http://api.weatherstack.com/current";

    private final RestTemplate restTemplate;
    public WeatherService(RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
    }

    //using rest template, get the weather details of a city
    public Weather getWeather(String city) {
        ResponseEntity<Weather> weather=restTemplate.exchange(API_URL+"?access_key="+API_KEY+"&query="+city, HttpMethod.GET,null,Weather.class);
        return weather.getBody();
    }


}
